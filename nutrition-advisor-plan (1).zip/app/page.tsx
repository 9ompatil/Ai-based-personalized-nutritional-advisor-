"use client"

import { useState, useEffect } from "react"
import { HealthForm } from "@/components/health-form"
import { NutritionResults } from "@/components/nutrition-results"
import { UserList } from "@/components/user-list"
import { Button } from "@/components/ui/button"
import { ChevronRight } from "lucide-react"
import type { User, HealthProfile } from "@/types/user"

type PageState = "home" | "users" | "form" | "edit" | "results"

export default function Home() {
  const [pageState, setPageState] = useState<PageState>("home")
  const [users, setUsers] = useState<User[]>([])
  const [selectedUser, setSelectedUser] = useState<User | null>(null)
  const [editingUser, setEditingUser] = useState<User | null>(null)

  useEffect(() => {
    const savedUsers = localStorage.getItem("nutrition_users")
    if (savedUsers) {
      setUsers(JSON.parse(savedUsers))
    }
  }, [])

  useEffect(() => {
    if (users.length > 0) {
      localStorage.setItem("nutrition_users", JSON.stringify(users))
    }
  }, [users])

  const handleFormSubmit = (name: string, profile: HealthProfile) => {
    if (editingUser) {
      const updatedUsers = users.map((u) =>
        u.id === editingUser.id ? { ...u, name, profile, createdAt: new Date().toISOString() } : u,
      )
      setUsers(updatedUsers)
      const updatedUser = updatedUsers.find((u) => u.id === editingUser.id)!
      setSelectedUser(updatedUser)
      setEditingUser(null)
    } else {
      const newUser: User = {
        id: Date.now().toString(),
        name,
        profile,
        createdAt: new Date().toISOString(),
        archived: false,
      }
      setUsers([...users, newUser])
      setSelectedUser(newUser)
    }
    setPageState("results")
  }

  const handleSelectUser = (user: User) => {
    setSelectedUser(user)
    setPageState("results")
  }

  const handleEditUser = (user: User) => {
    setEditingUser(user)
    setPageState("edit")
  }

  const handleDeleteUser = (userId: string) => {
    setUsers(users.filter((u) => u.id !== userId))
    if (selectedUser?.id === userId) {
      setSelectedUser(null)
    }
  }

  const handleArchiveUser = (userId: string) => {
    setUsers(users.map((u) => (u.id === userId ? { ...u, archived: !u.archived } : u)))
  }

  const handleReset = () => {
    setSelectedUser(null)
    setEditingUser(null)
    setPageState(users.length > 0 ? "users" : "home")
  }

  const handleAddNew = () => {
    setEditingUser(null)
    setPageState("form")
  }

  return (
    <main className="min-h-screen bg-background">
      {/* Header */}
      <header className="border-b border-border bg-card sticky top-0 z-50">
        <div className="container mx-auto px-4 py-4 max-w-7xl flex justify-between items-center">
          <h1 className="text-2xl font-bold">NutriAdvisor</h1>
          {pageState !== "home" && (
            <Button variant="ghost" onClick={handleReset}>
              {users.length > 0 ? "Users" : "Home"}
            </Button>
          )}
        </div>
      </header>

      {/* Main Content */}
      <div className="container mx-auto px-4 py-12 max-w-7xl">
        {pageState === "home" && users.length === 0 && (
          <div className="space-y-16 max-w-3xl">
            {/* Hero Section */}
            <div className="space-y-6">
              <h2 className="text-5xl md:text-6xl font-bold leading-tight">Your Personal Nutrition Advisor</h2>
              <p className="text-xl text-muted-foreground leading-relaxed">
                Get a personalized nutrition plan powered by science. Custom meal plans, macronutrient targets, and
                health metrics all in one place.
              </p>
              <Button onClick={() => setPageState("form")} className="gap-2 h-12 text-base" size="lg">
                Get Started <ChevronRight className="w-4 h-4" />
              </Button>
            </div>

            {/* Features */}
            <div className="space-y-4">
              <h3 className="text-lg font-semibold">What You Get</h3>
              <div className="space-y-3">
                <div className="flex gap-3">
                  <div className="text-2xl">📊</div>
                  <div>
                    <div className="font-semibold">Accurate Calculations</div>
                    <div className="text-muted-foreground text-sm">BMI, BMR, TDEE based on your data</div>
                  </div>
                </div>
                <div className="flex gap-3">
                  <div className="text-2xl">🍽️</div>
                  <div>
                    <div className="font-semibold">Personalized Meal Plans</div>
                    <div className="text-muted-foreground text-sm">7-day meals tailored to your preferences</div>
                  </div>
                </div>
                <div className="flex gap-3">
                  <div className="text-2xl">🎯</div>
                  <div>
                    <div className="font-semibold">Macro Tracking</div>
                    <div className="text-muted-foreground text-sm">Daily protein, carbs, and fat targets</div>
                  </div>
                </div>
                <div className="flex gap-3">
                  <div className="text-2xl">🛒</div>
                  <div>
                    <div className="font-semibold">Shopping List</div>
                    <div className="text-muted-foreground text-sm">Ready-to-use grocery checklist</div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        )}

        {(pageState === "users" || (pageState === "home" && users.length > 0)) && (
          <UserList
            users={users}
            onSelectUser={handleSelectUser}
            onEditUser={handleEditUser}
            onDeleteUser={handleDeleteUser}
            onArchiveUser={handleArchiveUser}
            onAddNew={handleAddNew}
          />
        )}

        {(pageState === "form" || pageState === "edit") && (
          <div className="flex justify-center">
            <HealthForm
              onSubmit={handleFormSubmit}
              initialName={editingUser?.name}
              initialProfile={editingUser?.profile}
              submitLabel={editingUser ? "Update Plan" : "Generate Plan"}
            />
          </div>
        )}

        {pageState === "results" && selectedUser && (
          <div>
            <NutritionResults profile={selectedUser.profile} onReset={handleReset} />
          </div>
        )}
      </div>
    </main>
  )
}
