export interface User {
  id: string
  name: string
  profile: HealthProfile
  createdAt: string
  archived: boolean
}

export interface HealthProfile {
  age: number
  height: number
  weight: number
  gender: "male" | "female"
  activityLevel: "sedentary" | "lightly-active" | "moderately-active" | "very-active"
  goal: "lose-weight" | "maintain" | "gain-muscle"
  dietaryPreferences: string[]
  allergies: string[]
  preferredCuisines: string[]
}
