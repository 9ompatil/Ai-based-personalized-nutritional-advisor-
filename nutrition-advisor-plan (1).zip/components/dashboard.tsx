"use client"

import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import type { HealthProfile } from "./health-form"

interface SavedProfile {
  id: string
  profile: HealthProfile
  date: string
}

interface DashboardProps {
  savedProfiles: SavedProfile[]
  onNewPlan: () => void
  onLoadProfile: (profile: HealthProfile) => void
}

export function Dashboard({ savedProfiles, onNewPlan, onLoadProfile }: DashboardProps) {
  const handleDelete = (id: string) => {
    const updated = savedProfiles.filter((p) => p.id !== id)
    localStorage.setItem("nutrition_profiles", JSON.stringify(updated))
    window.location.reload()
  }

  return (
    <div className="space-y-8">
      {/* Hero Section */}
      <div className="text-center mb-12">
        <h2 className="text-4xl md:text-5xl font-bold mb-4 text-pretty bg-gradient-to-r from-primary via-primary to-accent bg-clip-text text-transparent">
          Personal Nutrition Advisor
        </h2>
        <p className="text-lg text-muted-foreground text-balance mb-8 max-w-2xl mx-auto">
          Get a personalized diet plan based on your health metrics and fitness goals. Track your progress and achieve
          your nutrition targets.
        </p>
        <Button size="lg" onClick={onNewPlan} className="px-8">
          Create New Plan
        </Button>
      </div>

      {/* Features Grid */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-12">
        <Card className="hover:shadow-lg hover:border-primary/50 transition-all duration-300">
          <CardHeader>
            <div className="text-3xl mb-2">📊</div>
            <CardTitle>Personalized Analysis</CardTitle>
          </CardHeader>
          <CardContent>
            <p className="text-muted-foreground">
              Get detailed insights on your BMI, BMR, TDEE, and personalized calorie targets based on your goals.
            </p>
          </CardContent>
        </Card>

        <Card className="hover:shadow-lg hover:border-primary/50 transition-all duration-300">
          <CardHeader>
            <div className="text-3xl mb-2">🍽️</div>
            <CardTitle>Meal Planning</CardTitle>
          </CardHeader>
          <CardContent>
            <p className="text-muted-foreground">
              Receive customized meal suggestions tailored to your dietary preferences and fitness objectives.
            </p>
          </CardContent>
        </Card>

        <Card className="hover:shadow-lg hover:border-primary/50 transition-all duration-300">
          <CardHeader>
            <div className="text-3xl mb-2">🛒</div>
            <CardTitle>Shopping Lists</CardTitle>
          </CardHeader>
          <CardContent>
            <p className="text-muted-foreground">
              Auto-generated shopping lists make grocery shopping easy. Check off items as you shop.
            </p>
          </CardContent>
        </Card>
      </div>

      {/* Recent Plans Section */}
      {savedProfiles.length > 0 && (
        <div>
          <h3 className="text-2xl font-bold mb-4">Recent Plans</h3>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {savedProfiles.map((saved) => (
              <Card
                key={saved.id}
                className="hover:shadow-lg hover:border-primary/50 transition-all duration-300 group"
              >
                <CardHeader>
                  <CardTitle className="text-lg group-hover:text-primary transition-colors">{saved.date}</CardTitle>
                  <CardDescription>
                    {saved.profile.age}y • {saved.profile.weight}kg • {saved.profile.goal.replace("-", " ")}
                  </CardDescription>
                </CardHeader>
                <CardContent className="space-y-3">
                  <div className="space-y-1 text-sm">
                    <p>
                      <span className="text-muted-foreground">Height:</span> {saved.profile.height}cm
                    </p>
                    <p>
                      <span className="text-muted-foreground">Activity:</span>{" "}
                      {saved.profile.activityLevel.replace("-", " ")}
                    </p>
                    {saved.profile.dietaryPreferences.length > 0 && (
                      <p>
                        <span className="text-muted-foreground">Diet:</span>{" "}
                        {saved.profile.dietaryPreferences.join(", ")}
                      </p>
                    )}
                  </div>
                  <div className="flex gap-2">
                    <Button size="sm" onClick={() => onLoadProfile(saved.profile)} className="flex-1">
                      View
                    </Button>
                    <Button size="sm" variant="outline" onClick={() => handleDelete(saved.id)} className="flex-1">
                      Delete
                    </Button>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      )}

      {/* Empty State */}
      {savedProfiles.length === 0 && (
        <Card className="text-center py-12 border-dashed">
          <CardContent className="space-y-4">
            <p className="text-3xl">✨</p>
            <CardTitle>No Plans Yet</CardTitle>
            <p className="text-muted-foreground">Create your first nutrition plan to get started</p>
            <Button onClick={onNewPlan}>Create Your First Plan</Button>
          </CardContent>
        </Card>
      )}
    </div>
  )
}
