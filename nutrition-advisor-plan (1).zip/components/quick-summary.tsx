"use client"
import { Card } from "@/components/ui/card"
import { CheckCircle2, TrendingUp, Zap } from "lucide-react"
import type { HealthProfile } from "@/types/user"

interface QuickSummaryProps {
  profile: HealthProfile
  dailyCalories: number
  protein: number
  carbs: number
  fats: number
}

export function QuickSummary({ profile, dailyCalories, protein, carbs, fats }: QuickSummaryProps) {
  const summaryItems = [
    {
      icon: Zap,
      label: "Daily Calories",
      value: dailyCalories.toString(),
      color: "text-orange-600",
    },
    {
      icon: TrendingUp,
      label: "Protein Target",
      value: `${protein}g`,
      color: "text-red-600",
    },
    {
      icon: CheckCircle2,
      label: "Your Goal",
      value: profile.goal.replace("-", " "),
      color: "text-green-600",
    },
  ]

  return (
    <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
      {summaryItems.map((item, i) => {
        const Icon = item.icon
        return (
          <Card key={i} className="p-4">
            <div className="flex items-start gap-3">
              <Icon className={`w-5 h-5 ${item.color} flex-shrink-0 mt-1`} />
              <div>
                <p className="text-xs text-muted-foreground">{item.label}</p>
                <p className="text-2xl font-bold">{item.value}</p>
              </div>
            </div>
          </Card>
        )
      })}
    </div>
  )
}
