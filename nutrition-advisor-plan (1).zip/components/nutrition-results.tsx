"use client"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Input } from "@/components/ui/input"
import { Trash2, Plus, Download } from "lucide-react"
import { useState } from "react"
import type { HealthProfile } from "@/types/user"
import { WaterTracker } from "./water-tracker"
import { WorkoutRecommendations } from "./workout-recommendations"
import { QuickSummary } from "./quick-summary"

interface Meal {
  id: string
  name: string
  calories: number
  protein: number
  carbs: number
  fats: number
  fiber: number
}

interface Micronutrient {
  id: string
  name: string
  amount: string
  dailyValue: number
}

interface NutritionData {
  bmi: number
  bmr: number
  tdee: number
  dailyCalories: number
  protein: number
  carbs: number
  fats: number
  mealPlan: Meal[]
  shoppingList: string[]
  micronutrients: Micronutrient[]
}

function calculateNutrition(profile: HealthProfile): NutritionData {
  const bmi = profile.weight / (profile.height / 100) ** 2

  let bmr: number
  if (profile.gender === "male") {
    bmr = 10 * profile.weight + 6.25 * profile.height - 5 * profile.age + 5
  } else {
    bmr = 10 * profile.weight + 6.25 * profile.height - 5 * profile.age - 161
  }

  const activityMultipliers = {
    sedentary: 1.2,
    "lightly-active": 1.375,
    "moderately-active": 1.55,
    "very-active": 1.725,
  }
  const tdee = bmr * activityMultipliers[profile.activityLevel]

  let dailyCalories = tdee
  if (profile.goal === "lose-weight") {
    dailyCalories = tdee * 0.85 // 15% deficit
  } else if (profile.goal === "gain-muscle") {
    dailyCalories = tdee * 1.1 // 10% surplus
  }

  let protein: number, carbs: number, fats: number

  if (profile.goal === "gain-muscle") {
    protein = dailyCalories * 0.35 // 35%
    fats = dailyCalories * 0.25 // 25%
    carbs = dailyCalories * 0.4 // 40%
  } else if (profile.goal === "lose-weight") {
    protein = dailyCalories * 0.3 // 30%
    fats = dailyCalories * 0.25 // 25%
    carbs = dailyCalories * 0.45 // 45%
  } else {
    protein = dailyCalories * 0.25 // 25%
    fats = dailyCalories * 0.3 // 30%
    carbs = dailyCalories * 0.45 // 45%
  }

  const proteinGrams = protein / 4
  const carbsGrams = carbs / 4
  const fatsGrams = fats / 9

  const mealPlan = generateMealPlan(profile, Math.round(dailyCalories), proteinGrams, carbsGrams, fatsGrams)
  const shoppingList = generateShoppingList(profile, mealPlan)
  const micronutrients = generateMicronutrients(profile)

  return {
    bmi: Math.round(bmi * 10) / 10,
    bmr: Math.round(bmr),
    tdee: Math.round(tdee),
    dailyCalories: Math.round(dailyCalories),
    protein: Math.round(proteinGrams),
    carbs: Math.round(carbsGrams),
    fats: Math.round(fatsGrams),
    mealPlan,
    shoppingList,
    micronutrients,
  }
}

function generateMealPlan(
  profile: HealthProfile,
  calories: number,
  protein: number,
  carbs: number,
  fats: number,
): Meal[] {
  const isVegetarian = profile.dietaryPreferences.includes("Vegetarian") || profile.dietaryPreferences.includes("Vegan")
  const isVegan = profile.dietaryPreferences.includes("Vegan")
  const isKeto = profile.dietaryPreferences.includes("Keto")
  const isPaleo = profile.dietaryPreferences.includes("Paleo")
  const isMediterranean = profile.dietaryPreferences.includes("Mediterranean")

  const breakfastCal = Math.round(calories * 0.3)
  const snack1Cal = Math.round(calories * 0.15)
  const lunchCal = Math.round(calories * 0.3)
  const snack2Cal = Math.round(calories * 0.1)
  const dinnerCal = Math.round(calories * 0.35)

  const mealPlans: Record<string, Meal[]> = {
    default: [
      {
        id: "1",
        name: "Breakfast: Oatmeal with berries and almonds",
        calories: breakfastCal,
        protein: Math.round(protein * 0.25),
        carbs: Math.round(carbs * 0.35),
        fats: Math.round(fats * 0.25),
        fiber: 8,
      },
      {
        id: "2",
        name: "Snack: Greek yogurt with honey",
        calories: snack1Cal,
        protein: Math.round(protein * 0.15),
        carbs: Math.round(carbs * 0.15),
        fats: Math.round(fats * 0.1),
        fiber: 2,
      },
      {
        id: "3",
        name: "Lunch: Grilled chicken with brown rice and steamed broccoli",
        calories: lunchCal,
        protein: Math.round(protein * 0.35),
        carbs: Math.round(carbs * 0.3),
        fats: Math.round(fats * 0.2),
        fiber: 6,
      },
      {
        id: "4",
        name: "Snack: Apple with peanut butter",
        calories: snack2Cal,
        protein: Math.round(protein * 0.1),
        carbs: Math.round(carbs * 0.1),
        fats: Math.round(fats * 0.15),
        fiber: 4,
      },
      {
        id: "5",
        name: "Dinner: Salmon with sweet potato and asparagus",
        calories: dinnerCal,
        protein: Math.round(protein * 0.35),
        carbs: Math.round(carbs * 0.3),
        fats: Math.round(fats * 0.4),
        fiber: 7,
      },
    ],
    vegetarian: [
      {
        id: "1",
        name: "Breakfast: Spinach and feta omelet with whole grain toast",
        calories: breakfastCal,
        protein: Math.round(protein * 0.25),
        carbs: Math.round(carbs * 0.3),
        fats: Math.round(fats * 0.3),
        fiber: 5,
      },
      {
        id: "2",
        name: "Snack: Hummus with carrot and cucumber sticks",
        calories: snack1Cal,
        protein: Math.round(protein * 0.1),
        carbs: Math.round(carbs * 0.15),
        fats: Math.round(fats * 0.15),
        fiber: 4,
      },
      {
        id: "3",
        name: "Lunch: Chickpea salad with quinoa and vegetables",
        calories: lunchCal,
        protein: Math.round(protein * 0.3),
        carbs: Math.round(carbs * 0.35),
        fats: Math.round(fats * 0.2),
        fiber: 10,
      },
      {
        id: "4",
        name: "Snack: Mixed nuts and dried fruits",
        calories: snack2Cal,
        protein: Math.round(protein * 0.1),
        carbs: Math.round(carbs * 0.1),
        fats: Math.round(fats * 0.2),
        fiber: 3,
      },
      {
        id: "5",
        name: "Dinner: Lentil curry with brown rice",
        calories: dinnerCal,
        protein: Math.round(protein * 0.35),
        carbs: Math.round(carbs * 0.4),
        fats: Math.round(fats * 0.25),
        fiber: 12,
      },
    ],
    vegan: [
      {
        id: "1",
        name: "Breakfast: Chia seed pudding with almond milk",
        calories: breakfastCal,
        protein: Math.round(protein * 0.2),
        carbs: Math.round(carbs * 0.3),
        fats: Math.round(fats * 0.35),
        fiber: 11,
      },
      {
        id: "2",
        name: "Snack: Energy balls made with dates and walnuts",
        calories: snack1Cal,
        protein: Math.round(protein * 0.1),
        carbs: Math.round(carbs * 0.15),
        fats: Math.round(fats * 0.2),
        fiber: 4,
      },
      {
        id: "3",
        name: "Lunch: Tofu stir-fry with vegetables and jasmine rice",
        calories: lunchCal,
        protein: Math.round(protein * 0.35),
        carbs: Math.round(carbs * 0.35),
        fats: Math.round(fats * 0.2),
        fiber: 8,
      },
      {
        id: "4",
        name: "Snack: Hummus with apple slices",
        calories: snack2Cal,
        protein: Math.round(protein * 0.1),
        carbs: Math.round(carbs * 0.1),
        fats: Math.round(fats * 0.1),
        fiber: 5,
      },
      {
        id: "5",
        name: "Dinner: Chickpea pasta with marinara and vegetables",
        calories: dinnerCal,
        protein: Math.round(protein * 0.35),
        carbs: Math.round(carbs * 0.4),
        fats: Math.round(fats * 0.25),
        fiber: 9,
      },
    ],
    keto: [
      {
        id: "1",
        name: "Breakfast: Eggs with bacon and avocado",
        calories: breakfastCal,
        protein: Math.round(protein * 0.3),
        carbs: Math.round(carbs * 0.15),
        fats: Math.round(fats * 0.35),
        fiber: 3,
      },
      {
        id: "2",
        name: "Snack: Almonds and cheese",
        calories: snack1Cal,
        protein: Math.round(protein * 0.15),
        carbs: Math.round(carbs * 0.05),
        fats: Math.round(fats * 0.2),
        fiber: 2,
      },
      {
        id: "3",
        name: "Lunch: Cauliflower rice with ground beef",
        calories: lunchCal,
        protein: Math.round(protein * 0.35),
        carbs: Math.round(carbs * 0.2),
        fats: Math.round(fats * 0.3),
        fiber: 4,
      },
      {
        id: "4",
        name: "Snack: Macadamia nuts and olives",
        calories: snack2Cal,
        protein: Math.round(protein * 0.05),
        carbs: Math.round(carbs * 0.05),
        fats: Math.round(fats * 0.15),
        fiber: 2,
      },
      {
        id: "5",
        name: "Dinner: Steak with butter and green beans",
        calories: dinnerCal,
        protein: Math.round(protein * 0.4),
        carbs: Math.round(carbs * 0.15),
        fats: Math.round(fats * 0.4),
        fiber: 5,
      },
    ],
    paleo: [
      {
        id: "1",
        name: "Breakfast: Eggs with ghee and berries",
        calories: breakfastCal,
        protein: Math.round(protein * 0.25),
        carbs: Math.round(carbs * 0.25),
        fats: Math.round(fats * 0.3),
        fiber: 5,
      },
      {
        id: "2",
        name: "Snack: Raw almonds and dates",
        calories: snack1Cal,
        protein: Math.round(protein * 0.1),
        carbs: Math.round(carbs * 0.15),
        fats: Math.round(fats * 0.15),
        fiber: 3,
      },
      {
        id: "3",
        name: "Lunch: Grass-fed beef with sweet potato",
        calories: lunchCal,
        protein: Math.round(protein * 0.35),
        carbs: Math.round(carbs * 0.3),
        fats: Math.round(fats * 0.25),
        fiber: 6,
      },
      {
        id: "4",
        name: "Snack: Apple with almond butter",
        calories: snack2Cal,
        protein: Math.round(protein * 0.1),
        carbs: Math.round(carbs * 0.15),
        fats: Math.round(fats * 0.15),
        fiber: 4,
      },
      {
        id: "5",
        name: "Dinner: Wild-caught salmon with roasted vegetables",
        calories: dinnerCal,
        protein: Math.round(protein * 0.4),
        carbs: Math.round(carbs * 0.25),
        fats: Math.round(fats * 0.35),
        fiber: 8,
      },
    ],
    mediterranean: [
      {
        id: "1",
        name: "Breakfast: Greek yogurt with honey and walnuts",
        calories: breakfastCal,
        protein: Math.round(protein * 0.25),
        carbs: Math.round(carbs * 0.3),
        fats: Math.round(fats * 0.3),
        fiber: 3,
      },
      {
        id: "2",
        name: "Snack: Olives and feta cheese",
        calories: snack1Cal,
        protein: Math.round(protein * 0.15),
        carbs: Math.round(carbs * 0.05),
        fats: Math.round(fats * 0.2),
        fiber: 2,
      },
      {
        id: "3",
        name: "Lunch: Mediterranean salad with chickpeas",
        calories: lunchCal,
        protein: Math.round(protein * 0.3),
        carbs: Math.round(carbs * 0.35),
        fats: Math.round(fats * 0.25),
        fiber: 10,
      },
      {
        id: "4",
        name: "Snack: Fig and almond bar",
        calories: snack2Cal,
        protein: Math.round(protein * 0.1),
        carbs: Math.round(carbs * 0.15),
        fats: Math.round(fats * 0.1),
        fiber: 4,
      },
      {
        id: "5",
        name: "Dinner: Grilled sea bass with olive oil and herbs",
        calories: dinnerCal,
        protein: Math.round(protein * 0.4),
        carbs: Math.round(carbs * 0.25),
        fats: Math.round(fats * 0.35),
        fiber: 5,
      },
    ],
  }

  if (isVegan) return mealPlans.vegan
  if (isVegetarian) return mealPlans.vegetarian
  if (isKeto) return mealPlans.keto
  if (isPaleo) return mealPlans.paleo
  if (isMediterranean) return mealPlans.mediterranean
  return mealPlans.default
}

function generateMicronutrients(profile: HealthProfile): Micronutrient[] {
  const baseMicronutrients: Micronutrient[] = [
    { id: "1", name: "Vitamin D", amount: "15 mcg", dailyValue: 75 },
    { id: "2", name: "Vitamin B12", amount: "2.4 mcg", dailyValue: 100 },
    { id: "3", name: "Iron", amount: "18 mg", dailyValue: 100 },
    { id: "4", name: "Calcium", amount: "1000 mg", dailyValue: 100 },
    { id: "5", name: "Magnesium", amount: "400 mg", dailyValue: 95 },
    { id: "6", name: "Zinc", amount: "11 mg", dailyValue: 100 },
    { id: "7", name: "Vitamin C", amount: "90 mg", dailyValue: 100 },
    { id: "8", name: "Folate", amount: "400 mcg", dailyValue: 100 },
  ]

  if (profile.dietaryPreferences.includes("Vegan") || profile.dietaryPreferences.includes("Vegetarian")) {
    baseMicronutrients.push({ id: "9", name: "Vitamin B6", amount: "1.7 mg", dailyValue: 100 })
  }

  if (profile.goal === "gain-muscle") {
    baseMicronutrients.push({ id: "10", name: "Creatine", amount: "5 g", dailyValue: 100 })
  }

  return baseMicronutrients
}

function generateShoppingList(profile: HealthProfile, mealPlan: Meal[]): string[] {
  const baseList = [
    "Chicken breast",
    "Salmon fillets",
    "Eggs",
    "Greek yogurt",
    "Oats",
    "Brown rice",
    "Sweet potatoes",
    "Broccoli",
    "Spinach",
    "Carrots",
    "Apples",
    "Berries",
    "Almonds",
    "Olive oil",
    "Whole grain bread",
  ]

  const vegetarianList = [
    "Chickpeas",
    "Lentils",
    "Tofu",
    "Tempeh",
    "Quinoa",
    "Nuts",
    "Seeds",
    "Beans",
    "Cheese",
    "Milk",
  ]

  const veganList = [
    "Chickpeas",
    "Lentils",
    "Tofu",
    "Tempeh",
    "Quinoa",
    "Nuts",
    "Seeds",
    "Beans",
    "Almond milk",
    "Coconut milk",
    "Nutritional yeast",
  ]

  let list = [...baseList]

  if (profile.dietaryPreferences.includes("Vegan")) {
    list = list.filter((item) => !["Eggs", "Greek yogurt", "Cheese", "Milk"].includes(item))
    list.push(...veganList)
  } else if (profile.dietaryPreferences.includes("Vegetarian")) {
    list = list.filter((item) => !["Chicken breast", "Salmon fillets"].includes(item))
    list.push(...vegetarianList)
  }

  return [...new Set(list)].sort()
}

interface NutritionResultsProps {
  profile: HealthProfile
  onReset: () => void
}

export function NutritionResults({ profile, onReset }: NutritionResultsProps) {
  const nutrition = calculateNutrition(profile)

  const [meals, setMeals] = useState<Meal[]>(nutrition.mealPlan)
  const [newMealName, setNewMealName] = useState("")
  const [newMealCalories, setNewMealCalories] = useState("")
  const [newMealProtein, setNewMealProtein] = useState("")
  const [newMealCarbs, setNewMealCarbs] = useState("")
  const [newMealFats, setNewMealFats] = useState("")

  const [micronutrients, setMicronutrients] = useState<Micronutrient[]>(nutrition.micronutrients)
  const [newMicroName, setNewMicroName] = useState("")
  const [newMicroAmount, setNewMicroAmount] = useState("")
  const [newMicroDV, setNewMicroDV] = useState("")

  const [shoppingList, setShoppingList] = useState<{ id: string; name: string; checked: boolean }[]>(
    nutrition.shoppingList.map((item, i) => ({ id: `${i}-${item}`, name: item, checked: false })),
  )
  const [newItem, setNewItem] = useState("")

  const handleAddMeal = () => {
    if (newMealName.trim() && newMealCalories) {
      const newMeal: Meal = {
        id: Date.now().toString(),
        name: newMealName,
        calories: Number.parseInt(newMealCalories) || 0,
        protein: Number.parseInt(newMealProtein) || 0,
        carbs: Number.parseInt(newMealCarbs) || 0,
        fats: Number.parseInt(newMealFats) || 0,
        fiber: 0,
      }
      setMeals([...meals, newMeal])
      setNewMealName("")
      setNewMealCalories("")
      setNewMealProtein("")
      setNewMealCarbs("")
      setNewMealFats("")
    }
  }

  const handleDeleteMeal = (id: string) => {
    setMeals(meals.filter((meal) => meal.id !== id))
  }

  const handleAddMicronutrient = () => {
    if (newMicroName.trim() && newMicroAmount.trim()) {
      const newMicro: Micronutrient = {
        id: Date.now().toString(),
        name: newMicroName,
        amount: newMicroAmount,
        dailyValue: Number.parseInt(newMicroDV) || 0,
      }
      setMicronutrients([...micronutrients, newMicro])
      setNewMicroName("")
      setNewMicroAmount("")
      setNewMicroDV("")
    }
  }

  const handleDeleteMicronutrient = (id: string) => {
    setMicronutrients(micronutrients.filter((micro) => micro.id !== id))
  }

  const handleAddItem = () => {
    if (newItem.trim()) {
      setShoppingList([...shoppingList, { id: Date.now().toString(), name: newItem, checked: false }])
      setNewItem("")
    }
  }

  const handleDeleteItem = (id: string) => {
    setShoppingList(shoppingList.filter((item) => item.id !== id))
  }

  const handleToggleItem = (id: string) => {
    setShoppingList(shoppingList.map((item) => (item.id === id ? { ...item, checked: !item.checked } : item)))
  }

  const handleExportList = () => {
    const uncheckedItems = shoppingList.filter((item) => !item.checked).map((item) => item.name)
    const text = `Shopping List\n${new Date().toLocaleDateString()}\n\n${uncheckedItems.join("\n")}`
    const blob = new Blob([text], { type: "text/plain" })
    const url = URL.createObjectURL(blob)
    const a = document.createElement("a")
    a.href = url
    a.download = "shopping-list.txt"
    a.click()
  }

  const checkedCount = shoppingList.filter((item) => item.checked).length

  const getBMICategory = (bmi: number): string => {
    if (bmi < 18.5) return "Underweight"
    if (bmi < 25) return "Normal weight"
    if (bmi < 30) return "Overweight"
    return "Obese"
  }

  const getBMIColor = (bmi: number): string => {
    if (bmi < 18.5) return "text-blue-600"
    if (bmi < 25) return "text-green-600"
    if (bmi < 30) return "text-yellow-600"
    return "text-red-600"
  }

  const totalMealCalories = meals.reduce((sum, meal) => sum + meal.calories, 0)
  const totalMealProtein = meals.reduce((sum, meal) => sum + meal.protein, 0)
  const totalMealCarbs = meals.reduce((sum, meal) => sum + meal.carbs, 0)
  const totalMealFats = meals.reduce((sum, meal) => sum + meal.fats, 0)

  return (
    <div className="w-full space-y-6">
      <div className="flex justify-between items-center">
        <div>
          <h2 className="text-3xl font-bold">Your Nutrition Plan</h2>
          <p className="text-muted-foreground mt-1">Personalized recommendations based on your profile</p>
        </div>
        <Button variant="outline" onClick={onReset}>
          Start Over
        </Button>
      </div>

      <QuickSummary
        profile={profile}
        dailyCalories={nutrition.dailyCalories}
        protein={nutrition.protein}
        carbs={nutrition.carbs}
        fats={nutrition.fats}
      />

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <WaterTracker weight={profile.weight} />
        <WorkoutRecommendations profile={profile} />
      </div>

      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium">BMI</CardTitle>
          </CardHeader>
          <CardContent>
            <div className={`text-2xl font-bold ${getBMIColor(nutrition.bmi)}`}>{nutrition.bmi}</div>
            <p className="text-xs text-muted-foreground mt-1">{getBMICategory(nutrition.bmi)}</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium">BMR</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{nutrition.bmr}</div>
            <p className="text-xs text-muted-foreground mt-1">calories/day at rest</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium">TDEE</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{nutrition.tdee}</div>
            <p className="text-xs text-muted-foreground mt-1">calories/day active</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium">Target Daily</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-primary">{nutrition.dailyCalories}</div>
            <p className="text-xs text-muted-foreground mt-1">calories for your goal</p>
          </CardContent>
        </Card>
      </div>

      <Tabs defaultValue="macros" className="w-full">
        <TabsList className="grid w-full grid-cols-4">
          <TabsTrigger value="macros">Macronutrients</TabsTrigger>
          <TabsTrigger value="micros">Micronutrients</TabsTrigger>
          <TabsTrigger value="meals">Meal Plan</TabsTrigger>
          <TabsTrigger value="shopping">Shopping List</TabsTrigger>
        </TabsList>

        <TabsContent value="macros" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>Daily Macronutrient Breakdown</CardTitle>
              <CardDescription>Target macros based on your goal and activity level</CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="space-y-2">
                <div className="flex justify-between items-center">
                  <span className="font-semibold">Protein</span>
                  <span className="text-2xl font-bold text-chart-1">{nutrition.protein}g</span>
                </div>
                <div className="progress-bar">
                  <div className="progress-fill bg-chart-1" style={{ width: "30%" }}></div>
                </div>
                <p className="text-sm text-muted-foreground">~25-35% of daily calories</p>
              </div>

              <div className="space-y-2">
                <div className="flex justify-between items-center">
                  <span className="font-semibold">Carbohydrates</span>
                  <span className="text-2xl font-bold text-chart-2">{nutrition.carbs}g</span>
                </div>
                <div className="progress-bar">
                  <div className="progress-fill bg-chart-2" style={{ width: "40%" }}></div>
                </div>
                <p className="text-sm text-muted-foreground">~40-45% of daily calories</p>
              </div>

              <div className="space-y-2">
                <div className="flex justify-between items-center">
                  <span className="font-semibold">Fats</span>
                  <span className="text-2xl font-bold text-chart-3">{nutrition.fats}g</span>
                </div>
                <div className="progress-bar">
                  <div className="progress-fill bg-chart-3" style={{ width: "25%" }}></div>
                </div>
                <p className="text-sm text-muted-foreground">~25-30% of daily calories</p>
              </div>

              <div className="bg-secondary/50 border border-secondary rounded-lg p-4 mt-6">
                <p className="text-sm">
                  <span className="font-semibold">Total Daily Intake:</span> {nutrition.dailyCalories} calories
                </p>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="micros" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>Daily Micronutrients</CardTitle>
              <CardDescription>Essential vitamins and minerals for optimal health</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="flex gap-2">
                <Input
                  placeholder="Nutrient name (e.g., Vitamin D)"
                  value={newMicroName}
                  onChange={(e) => setNewMicroName(e.target.value)}
                  className="flex-1"
                />
                <Input
                  placeholder="Amount (e.g., 15 mcg)"
                  value={newMicroAmount}
                  onChange={(e) => setNewMicroAmount(e.target.value)}
                  className="w-32"
                />
                <Input
                  placeholder="DV %"
                  type="number"
                  value={newMicroDV}
                  onChange={(e) => setNewMicroDV(e.target.value)}
                  className="w-24"
                />
                <Button onClick={handleAddMicronutrient} className="gap-2">
                  <Plus className="w-4 h-4" />
                  Add
                </Button>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                {micronutrients.map((micro) => (
                  <div
                    key={micro.id}
                    className="flex items-center justify-between p-4 bg-secondary/30 rounded-lg border border-secondary hover:bg-secondary/50 transition-colors group"
                  >
                    <div className="flex-1">
                      <p className="font-semibold">{micro.name}</p>
                      <p className="text-sm text-muted-foreground">{micro.amount}</p>
                    </div>
                    <div className="flex items-center gap-3">
                      <div className="text-right">
                        <p className="text-sm font-semibold text-primary">{micro.dailyValue}%</p>
                        <p className="text-xs text-muted-foreground">Daily Value</p>
                      </div>
                      <button
                        onClick={() => handleDeleteMicronutrient(micro.id)}
                        className="opacity-0 group-hover:opacity-100 transition-opacity p-1 hover:bg-destructive/10 rounded"
                      >
                        <Trash2 className="w-4 h-4 text-destructive" />
                      </button>
                    </div>
                  </div>
                ))}
              </div>

              <div className="bg-accent/10 border border-accent rounded-lg p-4 mt-6">
                <p className="text-sm">
                  <span className="font-semibold">Note:</span> Micronutrients are essential for various bodily
                  functions. Aim to meet these targets through whole foods when possible.
                </p>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="meals" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>Daily Meal Plan</CardTitle>
              <CardDescription>Meals with complete nutritional breakdown</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="grid grid-cols-1 md:grid-cols-5 gap-2">
                <Input
                  placeholder="Meal name"
                  value={newMealName}
                  onChange={(e) => setNewMealName(e.target.value)}
                  className="md:col-span-2"
                />
                <Input
                  placeholder="Cal"
                  type="number"
                  value={newMealCalories}
                  onChange={(e) => setNewMealCalories(e.target.value)}
                />
                <Input
                  placeholder="Protein (g)"
                  type="number"
                  value={newMealProtein}
                  onChange={(e) => setNewMealProtein(e.target.value)}
                />
                <Input
                  placeholder="Carbs (g)"
                  type="number"
                  value={newMealCarbs}
                  onChange={(e) => setNewMealCarbs(e.target.value)}
                />
                <Input
                  placeholder="Fats (g)"
                  type="number"
                  value={newMealFats}
                  onChange={(e) => setNewMealFats(e.target.value)}
                />
                <Button onClick={handleAddMeal} className="gap-2 md:col-span-5">
                  <Plus className="w-4 h-4" />
                  Add Custom Meal
                </Button>
              </div>

              <div className="space-y-3">
                {meals.map((meal, index) => (
                  <div
                    key={meal.id}
                    className="p-4 bg-secondary/30 rounded-lg border border-secondary hover:bg-secondary/50 transition-colors group"
                  >
                    <div className="flex items-start gap-3">
                      <div className="flex-shrink-0 w-8 h-8 rounded-full bg-primary text-primary-foreground flex items-center justify-center text-sm font-semibold">
                        {index + 1}
                      </div>
                      <div className="flex-1">
                        <p className="font-medium mb-2">{meal.name}</p>
                        <div className="grid grid-cols-2 md:grid-cols-5 gap-2 text-sm">
                          <div>
                            <p className="text-muted-foreground text-xs">Calories</p>
                            <p className="font-semibold">{meal.calories}</p>
                          </div>
                          <div>
                            <p className="text-muted-foreground text-xs">Protein</p>
                            <p className="font-semibold text-chart-1">{meal.protein}g</p>
                          </div>
                          <div>
                            <p className="text-muted-foreground text-xs">Carbs</p>
                            <p className="font-semibold text-chart-2">{meal.carbs}g</p>
                          </div>
                          <div>
                            <p className="text-muted-foreground text-xs">Fats</p>
                            <p className="font-semibold text-chart-3">{meal.fats}g</p>
                          </div>
                          <div>
                            <p className="text-muted-foreground text-xs">Fiber</p>
                            <p className="font-semibold">{meal.fiber}g</p>
                          </div>
                        </div>
                      </div>
                      <button
                        onClick={() => handleDeleteMeal(meal.id)}
                        className="opacity-0 group-hover:opacity-100 transition-opacity p-2 hover:bg-destructive/10 rounded"
                      >
                        <Trash2 className="w-4 h-4 text-destructive" />
                      </button>
                    </div>
                  </div>
                ))}
              </div>

              <div className="bg-primary/5 border border-primary/20 rounded-lg p-4">
                <p className="text-sm font-semibold mb-2">Daily Totals</p>
                <div className="grid grid-cols-4 gap-4 text-sm">
                  <div>
                    <p className="text-muted-foreground">Calories</p>
                    <p className="font-bold text-lg">{totalMealCalories}</p>
                  </div>
                  <div>
                    <p className="text-muted-foreground">Protein</p>
                    <p className="font-bold text-lg text-chart-1">{totalMealProtein}g</p>
                  </div>
                  <div>
                    <p className="text-muted-foreground">Carbs</p>
                    <p className="font-bold text-lg text-chart-2">{totalMealCarbs}g</p>
                  </div>
                  <div>
                    <p className="text-muted-foreground">Fats</p>
                    <p className="font-bold text-lg text-chart-3">{totalMealFats}g</p>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="shopping" className="space-y-4">
          <Card>
            <CardHeader className="pb-2">
              <div className="flex justify-between items-start">
                <div>
                  <CardTitle>Shopping List</CardTitle>
                  <CardDescription>Essential items for your meal plan</CardDescription>
                </div>
                <Button variant="outline" size="sm" onClick={handleExportList} className="gap-2 bg-transparent">
                  <Download className="w-4 h-4" />
                  Export
                </Button>
              </div>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="flex gap-2">
                <Input
                  placeholder="Add custom item..."
                  value={newItem}
                  onChange={(e) => setNewItem(e.target.value)}
                  onKeyPress={(e) => e.key === "Enter" && handleAddItem()}
                />
                <Button onClick={handleAddItem} className="gap-2">
                  <Plus className="w-4 h-4" />
                  Add
                </Button>
              </div>

              <div className="text-sm text-muted-foreground">
                {checkedCount} of {shoppingList.length} items checked
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-2 max-h-96 overflow-y-auto">
                {shoppingList.map((item) => (
                  <div
                    key={item.id}
                    className="flex items-center gap-2 p-3 bg-secondary/30 rounded border border-secondary hover:bg-secondary/50 transition-colors group"
                  >
                    <input
                      type="checkbox"
                      className="rounded"
                      id={item.id}
                      checked={item.checked}
                      onChange={() => handleToggleItem(item.id)}
                    />
                    <label
                      htmlFor={item.id}
                      className={`text-sm cursor-pointer flex-1 ${item.checked ? "line-through text-muted-foreground" : ""}`}
                    >
                      {item.name}
                    </label>
                    <button
                      onClick={() => handleDeleteItem(item.id)}
                      className="opacity-0 group-hover:opacity-100 transition-opacity p-1 hover:bg-destructive/10 rounded"
                    >
                      <Trash2 className="w-4 h-4 text-destructive" />
                    </button>
                  </div>
                ))}
              </div>

              <div className="bg-muted/50 border border-muted rounded-lg p-4">
                <p className="text-sm">
                  <span className="font-semibold">Total items:</span> {shoppingList.length}
                </p>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>

      <Card>
        <CardHeader>
          <CardTitle>Your Profile</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
            <div>
              <p className="text-sm text-muted-foreground">Age</p>
              <p className="font-semibold">{profile.age} years</p>
            </div>
            <div>
              <p className="text-sm text-muted-foreground">Height</p>
              <p className="font-semibold">{profile.height} cm</p>
            </div>
            <div>
              <p className="text-sm text-muted-foreground">Weight</p>
              <p className="font-semibold">{profile.weight} kg</p>
            </div>
            <div>
              <p className="text-sm text-muted-foreground">Activity Level</p>
              <p className="font-semibold capitalize">{profile.activityLevel.replace("-", " ")}</p>
            </div>
            <div>
              <p className="text-sm text-muted-foreground">Gender</p>
              <p className="font-semibold capitalize">{profile.gender}</p>
            </div>
            <div>
              <p className="text-sm text-muted-foreground">Goal</p>
              <p className="font-semibold capitalize">{profile.goal.replace("-", " ")}</p>
            </div>
            <div className="md:col-span-2">
              <p className="text-sm text-muted-foreground">Dietary Preferences</p>
              <p className="font-semibold">
                {profile.dietaryPreferences.length > 0 ? profile.dietaryPreferences.join(", ") : "None selected"}
              </p>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  )
}
