"use client"

import type React from "react"
import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import type { HealthProfile } from "@/types/user"

interface HealthFormProps {
  onSubmit: (name: string, profile: HealthProfile) => void
  initialName?: string
  initialProfile?: HealthProfile
  submitLabel?: string
}

export function HealthForm({ onSubmit, initialName, initialProfile, submitLabel = "Generate Plan" }: HealthFormProps) {
  const [name, setName] = useState(initialName || "")
  const [age, setAge] = useState(initialProfile?.age.toString() || "")
  const [height, setHeight] = useState(initialProfile?.height.toString() || "")
  const [weight, setWeight] = useState(initialProfile?.weight.toString() || "")
  const [gender, setGender] = useState<"male" | "female">(initialProfile?.gender || "male")
  const [activityLevel, setActivityLevel] = useState<
    "sedentary" | "lightly-active" | "moderately-active" | "very-active"
  >(initialProfile?.activityLevel || "moderately-active")
  const [goal, setGoal] = useState<"lose-weight" | "maintain" | "gain-muscle">(initialProfile?.goal || "maintain")
  const [dietaryPreferences, setDietaryPreferences] = useState<string[]>(initialProfile?.dietaryPreferences || [])
  const [allergies, setAllergies] = useState<string[]>(initialProfile?.allergies || [])
  const [preferredCuisines, setPreferredCuisines] = useState<string[]>(initialProfile?.preferredCuisines || [])

  const dietaryOptions = [
    "Vegetarian",
    "Vegan",
    "Gluten-Free",
    "Dairy-Free",
    "Keto",
    "Paleo",
    "Mediterranean",
    "Low-Carb",
  ]
  const allergyOptions = ["Nuts", "Dairy", "Gluten", "Eggs", "Shellfish", "Soy", "Fish"]
  const cuisineOptions = [
    "Asian",
    "Mediterranean",
    "Indian",
    "Italian",
    "Mexican",
    "Middle Eastern",
    "Japanese",
    "American",
  ]

  const handleToggle = (item: string, list: string[], setList: (list: string[]) => void) => {
    setList(list.includes(item) ? list.filter((i) => i !== item) : [...list, item])
  }

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    if (!name.trim() || !age || !height || !weight) {
      alert("Please fill in all required fields including name")
      return
    }

    onSubmit(name.trim(), {
      age: Number.parseInt(age),
      height: Number.parseFloat(height),
      weight: Number.parseFloat(weight),
      gender,
      activityLevel,
      goal,
      dietaryPreferences,
      allergies,
      preferredCuisines,
    })
  }

  return (
    <Card className="w-full max-w-2xl border shadow-sm">
      <CardHeader className="pb-6">
        <CardTitle className="text-3xl">Your Profile</CardTitle>
        <CardDescription>Tell us about yourself for personalized recommendations</CardDescription>
      </CardHeader>
      <CardContent>
        <form onSubmit={handleSubmit} className="space-y-6">
          <div className="space-y-2">
            <Label htmlFor="name">Name *</Label>
            <Input
              id="name"
              type="text"
              placeholder="Enter your name"
              value={name}
              onChange={(e) => setName(e.target.value)}
            />
          </div>

          <Tabs defaultValue="basics" className="w-full">
            <TabsList className="grid w-full grid-cols-3">
              <TabsTrigger value="basics">Basics</TabsTrigger>
              <TabsTrigger value="dietary">Dietary</TabsTrigger>
              <TabsTrigger value="preferences">Cuisines</TabsTrigger>
            </TabsList>

            <TabsContent value="basics" className="space-y-6 mt-6">
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="age">Age *</Label>
                  <Input
                    id="age"
                    type="number"
                    placeholder="30"
                    value={age}
                    onChange={(e) => setAge(e.target.value)}
                    min="1"
                    max="120"
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="height">Height (cm) *</Label>
                  <Input
                    id="height"
                    type="number"
                    placeholder="175"
                    value={height}
                    onChange={(e) => setHeight(e.target.value)}
                    step="0.1"
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="weight">Weight (kg) *</Label>
                  <Input
                    id="weight"
                    type="number"
                    placeholder="75"
                    value={weight}
                    onChange={(e) => setWeight(e.target.value)}
                    step="0.1"
                  />
                </div>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="gender">Gender</Label>
                  <Select value={gender} onValueChange={(value: any) => setGender(value)}>
                    <SelectTrigger id="gender">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="male">Male</SelectItem>
                      <SelectItem value="female">Female</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                <div className="space-y-2">
                  <Label htmlFor="activity">Activity Level</Label>
                  <Select value={activityLevel} onValueChange={(value: any) => setActivityLevel(value)}>
                    <SelectTrigger id="activity">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="sedentary">Sedentary</SelectItem>
                      <SelectItem value="lightly-active">Lightly Active</SelectItem>
                      <SelectItem value="moderately-active">Moderately Active</SelectItem>
                      <SelectItem value="very-active">Very Active</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>

              <div className="space-y-2">
                <Label htmlFor="goal">Goal</Label>
                <Select value={goal} onValueChange={(value: any) => setGoal(value)}>
                  <SelectTrigger id="goal">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="lose-weight">Lose Weight</SelectItem>
                    <SelectItem value="maintain">Maintain</SelectItem>
                    <SelectItem value="gain-muscle">Gain Muscle</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </TabsContent>

            <TabsContent value="dietary" className="space-y-6 mt-6">
              <div className="space-y-4">
                <div>
                  <Label className="mb-3 block">Dietary Preferences</Label>
                  <div className="grid grid-cols-2 md:grid-cols-4 gap-2">
                    {dietaryOptions.map((option) => (
                      <button
                        key={option}
                        type="button"
                        onClick={() => handleToggle(option, dietaryPreferences, setDietaryPreferences)}
                        className={`px-3 py-2 rounded border text-sm transition-colors ${
                          dietaryPreferences.includes(option)
                            ? "border-primary bg-primary text-primary-foreground"
                            : "border-border bg-card hover:border-primary"
                        }`}
                      >
                        {option}
                      </button>
                    ))}
                  </div>
                </div>

                <div>
                  <Label className="mb-3 block">Allergies</Label>
                  <div className="grid grid-cols-2 md:grid-cols-4 gap-2">
                    {allergyOptions.map((option) => (
                      <button
                        key={option}
                        type="button"
                        onClick={() => handleToggle(option, allergies, setAllergies)}
                        className={`px-3 py-2 rounded border text-sm transition-colors ${
                          allergies.includes(option)
                            ? "border-destructive bg-destructive text-destructive-foreground"
                            : "border-border bg-card hover:border-destructive"
                        }`}
                      >
                        {option}
                      </button>
                    ))}
                  </div>
                </div>
              </div>
            </TabsContent>

            <TabsContent value="preferences" className="space-y-6 mt-6">
              <div>
                <Label className="mb-3 block">Preferred Cuisines</Label>
                <div className="grid grid-cols-2 md:grid-cols-4 gap-2">
                  {cuisineOptions.map((option) => (
                    <button
                      key={option}
                      type="button"
                      onClick={() => handleToggle(option, preferredCuisines, setPreferredCuisines)}
                      className={`px-3 py-2 rounded border text-sm transition-colors ${
                        preferredCuisines.includes(option)
                          ? "border-primary bg-primary text-primary-foreground"
                          : "border-border bg-card hover:border-primary"
                      }`}
                    >
                      {option}
                    </button>
                  ))}
                </div>
              </div>
            </TabsContent>
          </Tabs>

          <Button type="submit" className="w-full" size="lg">
            {submitLabel}
          </Button>
        </form>
      </CardContent>
    </Card>
  )
}
