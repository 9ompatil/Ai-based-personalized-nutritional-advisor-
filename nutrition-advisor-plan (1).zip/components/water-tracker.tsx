"use client"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Droplet, Plus, Minus } from "lucide-react"
import { useState } from "react"

interface WaterTrackerProps {
  weight: number
}

export function WaterTracker({ weight }: WaterTrackerProps) {
  // General recommendation: 35ml per kg of body weight
  const dailyGoal = Math.round(weight * 35)
  const [glassesConsumed, setGlassesConsumed] = useState(0)
  const glassSize = 250 // ml
  const waterConsumed = glassesConsumed * glassSize
  const percentage = Math.min((waterConsumed / dailyGoal) * 100, 100)

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <Droplet className="w-5 h-5 text-blue-500" />
          Hydration Tracker
        </CardTitle>
        <CardDescription>Stay hydrated throughout the day</CardDescription>
      </CardHeader>
      <CardContent className="space-y-4">
        <div className="text-center space-y-2">
          <div className="text-4xl font-bold text-blue-600">{waterConsumed}ml</div>
          <div className="text-sm text-muted-foreground">Goal: {dailyGoal}ml per day</div>
        </div>

        <div className="w-full bg-secondary rounded-full h-3 overflow-hidden">
          <div className="bg-blue-500 h-full transition-all duration-300" style={{ width: `${percentage}%` }}></div>
        </div>

        <div className="flex gap-2 justify-center">
          <Button variant="outline" size="sm" onClick={() => setGlassesConsumed(Math.max(0, glassesConsumed - 1))}>
            <Minus className="w-4 h-4" />
          </Button>
          <div className="px-4 py-2 bg-secondary rounded">
            <span className="font-semibold">{glassesConsumed} glasses</span>
          </div>
          <Button variant="outline" size="sm" onClick={() => setGlassesConsumed(glassesConsumed + 1)}>
            <Plus className="w-4 h-4" />
          </Button>
        </div>

        <div className="bg-blue-50 dark:bg-blue-950/30 border border-blue-200 dark:border-blue-800 rounded-lg p-3">
          <p className="text-sm text-blue-900 dark:text-blue-100">
            💧 Drink water regularly throughout the day. A good indicator is pale yellow urine.
          </p>
        </div>
      </CardContent>
    </Card>
  )
}
