"use client"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Dumbbell } from "lucide-react"
import type { HealthProfile } from "@/types/user"

interface WorkoutRecommendationsProps {
  profile: HealthProfile
}

export function WorkoutRecommendations({ profile }: WorkoutRecommendationsProps) {
  const getWorkouts = () => {
    const workouts = {
      "lose-weight": [
        { name: "Cardio", duration: "30-45 mins", frequency: "4-5x/week", description: "Running, cycling, HIIT" },
        { name: "Strength", duration: "30 mins", frequency: "2-3x/week", description: "Resistance training" },
        { name: "Stretching", duration: "10-15 mins", frequency: "Daily", description: "Flexibility & recovery" },
      ],
      maintain: [
        { name: "Cardio", duration: "20-30 mins", frequency: "3x/week", description: "Moderate intensity" },
        { name: "Strength", duration: "45-60 mins", frequency: "3-4x/week", description: "Full body or split" },
        { name: "Flexibility", duration: "15 mins", frequency: "2-3x/week", description: "Yoga or stretching" },
      ],
      "gain-muscle": [
        {
          name: "Strength Training",
          duration: "60-90 mins",
          frequency: "4-5x/week",
          description: "Progressive overload",
        },
        { name: "Rest Days", duration: "-", frequency: "2-3x/week", description: "Recovery is crucial" },
        { name: "Light Cardio", duration: "15-20 mins", frequency: "1-2x/week", description: "Optional on rest days" },
      ],
    }

    return workouts[profile.goal] || workouts.maintain
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <Dumbbell className="w-5 h-5" />
          Workout Plan
        </CardTitle>
        <CardDescription>Recommended exercises for your goal</CardDescription>
      </CardHeader>
      <CardContent>
        <div className="space-y-3">
          {getWorkouts().map((workout, index) => (
            <div key={index} className="border border-border rounded-lg p-3 hover:bg-secondary/50 transition-colors">
              <div className="flex justify-between items-start mb-1">
                <h4 className="font-semibold">{workout.name}</h4>
                <span className="text-xs bg-primary/10 text-primary px-2 py-1 rounded">{workout.frequency}</span>
              </div>
              <p className="text-sm text-muted-foreground mb-1">{workout.description}</p>
              <p className="text-xs text-muted-foreground">Duration: {workout.duration}</p>
            </div>
          ))}
        </div>

        <div className="bg-amber-50 dark:bg-amber-950/30 border border-amber-200 dark:border-amber-800 rounded-lg p-3 mt-4">
          <p className="text-sm text-amber-900 dark:text-amber-100">
            💪 Rest and recovery are important. Allow 48 hours between training the same muscle groups.
          </p>
        </div>
      </CardContent>
    </Card>
  )
}
