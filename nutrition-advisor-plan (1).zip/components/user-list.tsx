"use client"

import { useState } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { User, Plus, Edit, Trash2, Archive, ArchiveRestore } from "lucide-react"
import type { User as UserType } from "@/types/user"

interface UserListProps {
  users: UserType[]
  onSelectUser: (user: UserType) => void
  onEditUser: (user: UserType) => void
  onDeleteUser: (userId: string) => void
  onArchiveUser: (userId: string) => void
  onAddNew: () => void
}

export function UserList({ users, onSelectUser, onEditUser, onDeleteUser, onArchiveUser, onAddNew }: UserListProps) {
  const [showArchived, setShowArchived] = useState(false)

  const activeUsers = users.filter((u) => !u.archived)
  const archivedUsers = users.filter((u) => u.archived)
  const displayUsers = showArchived ? archivedUsers : activeUsers

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <div>
          <h2 className="text-3xl font-bold">Manage Users</h2>
          <p className="text-muted-foreground mt-1">
            {activeUsers.length} active user{activeUsers.length !== 1 ? "s" : ""}
            {archivedUsers.length > 0 && `, ${archivedUsers.length} archived`}
          </p>
        </div>
        <div className="flex gap-2">
          <Button variant="outline" onClick={() => setShowArchived(!showArchived)}>
            {showArchived ? <ArchiveRestore className="w-4 h-4 mr-2" /> : <Archive className="w-4 h-4 mr-2" />}
            {showArchived ? "Show Active" : "Show Archived"}
          </Button>
          <Button onClick={onAddNew} className="gap-2">
            <Plus className="w-4 h-4" />
            Add User
          </Button>
        </div>
      </div>

      {displayUsers.length === 0 ? (
        <Card>
          <CardContent className="py-12 text-center">
            <User className="w-12 h-12 mx-auto mb-4 text-muted-foreground" />
            <p className="text-muted-foreground">
              {showArchived ? "No archived users" : "No users yet. Add your first user to get started."}
            </p>
          </CardContent>
        </Card>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {displayUsers.map((user) => (
            <Card
              key={user.id}
              className="hover:border-primary transition-colors cursor-pointer group"
              onClick={() => onSelectUser(user)}
            >
              <CardHeader className="pb-3">
                <div className="flex justify-between items-start">
                  <div className="flex items-center gap-2">
                    <div className="w-10 h-10 rounded-full bg-primary/10 flex items-center justify-center">
                      <User className="w-5 h-5 text-primary" />
                    </div>
                    <div>
                      <CardTitle className="text-lg">{user.name}</CardTitle>
                      <CardDescription className="text-xs">
                        {new Date(user.createdAt).toLocaleDateString()}
                      </CardDescription>
                    </div>
                  </div>
                  {user.archived && (
                    <span className="text-xs bg-secondary text-secondary-foreground px-2 py-1 rounded">Archived</span>
                  )}
                </div>
              </CardHeader>
              <CardContent className="space-y-3">
                <div className="grid grid-cols-2 gap-2 text-sm">
                  <div>
                    <p className="text-muted-foreground text-xs">Age / Gender</p>
                    <p className="font-medium">
                      {user.profile.age}y / {user.profile.gender === "male" ? "M" : "F"}
                    </p>
                  </div>
                  <div>
                    <p className="text-muted-foreground text-xs">Weight</p>
                    <p className="font-medium">{user.profile.weight} kg</p>
                  </div>
                </div>
                <div>
                  <p className="text-muted-foreground text-xs">Goal</p>
                  <p className="font-medium text-sm capitalize">{user.profile.goal.replace("-", " ")}</p>
                </div>

                <div className="flex gap-2 pt-2 opacity-0 group-hover:opacity-100 transition-opacity">
                  <Button
                    variant="outline"
                    size="sm"
                    className="flex-1 bg-transparent"
                    onClick={(e) => {
                      e.stopPropagation()
                      onEditUser(user)
                    }}
                  >
                    <Edit className="w-3 h-3 mr-1" />
                    Edit
                  </Button>
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={(e) => {
                      e.stopPropagation()
                      onArchiveUser(user.id)
                    }}
                  >
                    {user.archived ? <ArchiveRestore className="w-3 h-3" /> : <Archive className="w-3 h-3" />}
                  </Button>
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={(e) => {
                      e.stopPropagation()
                      if (confirm(`Delete ${user.name}? This cannot be undone.`)) {
                        onDeleteUser(user.id)
                      }
                    }}
                  >
                    <Trash2 className="w-3 h-3 text-destructive" />
                  </Button>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      )}
    </div>
  )
}
